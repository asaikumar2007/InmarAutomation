package com.inmar.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class paymentPage {
	
	WebDriver ldriver;
	
	public paymentPage(WebDriver rdriver)
	{
		ldriver  = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy(className="bankwire")
	WebElement paymentModeBankWire;
	
	@FindBy(className="cheque")
	WebElement paymentModeCheque;	
	
	@FindBy(className="cheque-indent")
	WebElement orderStatusMsg;	
	
	@FindBy(xpath="//div[@id='center_column']/p[1]")
	WebElement chequeOrderStatusMsg;
	
	@FindBy(xpath="//p[@id='cart_navigation']/button")
	WebElement btnConfirmMyOrder;
	
	

	public void clickOnPaymentModeBankWire()
	{
		paymentModeBankWire.click();
	}
	
	public void clickOnPaymentModeCheque()
	{
		paymentModeCheque.click();
	}
	
	public void clickOnBtnConfirmMyOrder()
	{
		btnConfirmMyOrder.click();
	}
	
	public String orderStatusMsg()
	{
		return orderStatusMsg.getText();
	}
	
	public String chequeOrderStatusMsg()
	{
		return chequeOrderStatusMsg.getText();
	}

}
