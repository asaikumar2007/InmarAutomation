package com.inmar.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;



public class myStorePage {
	
	WebDriver ldriver;
	
	public myStorePage(WebDriver rdriver)
	{
		ldriver  = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy(linkText="Women")
	WebElement linkWomen;
	
	@FindBy(xpath="//ul[@class='product_list grid row']/li[1]")
	WebElement wProduct1;
	
	@FindBy(xpath="//div[@class='button-container']/a[@title='Add to cart']")
	WebElement productAddToCart;
	
	@FindBy(xpath="//div[@class='clearfix']/div/h2[1]")
	WebElement addToCartMsg;
	
	@FindBy(xpath="//div[@class='button-container']/a/span")
	WebElement btnProceedToChekOut;
	
	@FindBy(xpath="//p[@class='cart_navigation clearfix']/a/span")
	WebElement orderPageBtnProceedToCheckOut;
	
	@FindBy(id="addressesAreEquals")
	WebElement checkBoxBillingAddress;
	
	@FindBy(name="processAddress")
	WebElement processAddessCheckOut;
	
	@FindBy(className="checker")
	WebElement shippingCheckBox;
	
	@FindBy(name="processCarrier")
	WebElement processCarrierCheckOut;
	
	@FindBy(id="search_query_top")
	WebElement txtSearchQuery;
	
	@FindBy(name="submit_search")
	WebElement btnSearch;	

	public void clickOnWomenStore()
	{
		// TODO Auto-generated method stub
		linkWomen.click();
	}
	
	public void moveToProdcut()
	{
		wProduct1.click();
	}
	
	public void clickOnAddToCart()
	{
		productAddToCart.click();
	}
	
	public String addToCartMsg()
	{
		return addToCartMsg.getText();
	}
	
	public void clickOnProceedToCheckOutButton()
	{
		btnProceedToChekOut.click();
	}
	
	public void orderPageBtnProceedToCheckOut()
	{
		orderPageBtnProceedToCheckOut.click();
	}
	
	public boolean verifyBillingAddressCheckBox()
	{
		return checkBoxBillingAddress.isSelected();
	}
	
	public void clickOnProcessAddessCheckOut()
	{
		processAddessCheckOut.click();
	}
	
	public void clickOnShippingCheckBox()
	{
		shippingCheckBox.click();
	}
	
	public void clickOnProcessCarrierCheckOut()
	{
		processCarrierCheckOut.click();
	}
	
	public void txtSearchQuery(String searchProduct)
	{
		txtSearchQuery.sendKeys(searchProduct);
	}
	
	public void btnSearch()
	{
		btnSearch.click();
	}
	

}
