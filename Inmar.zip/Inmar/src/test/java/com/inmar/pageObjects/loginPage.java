package com.inmar.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class loginPage {
	
	WebDriver ldriver;
	
	public loginPage(WebDriver rdriver)
	{
		ldriver  = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy(id="email")
	WebElement txtEmail;
	
	@FindBy(id="passwd")
	WebElement txtPassword;
	
	@FindBy(id="SubmitLogin")
	WebElement btnSubmitLogin;
	
	@FindBy(xpath="//div[@class='alert alert-danger']/ol/li")
	WebElement emailErrorMsg;
	
	public void txtEmail(String email)
	{
		txtEmail.sendKeys(email);
	}
	
	public void txtPassword(String pwd)
	{
		txtPassword.sendKeys(pwd);
	}
	
	public void btnSubmitLogin()
	{
		btnSubmitLogin.click();
	}
	
	public String getEmailErrorMsg()
	{
		return emailErrorMsg.getText();
	}

}
