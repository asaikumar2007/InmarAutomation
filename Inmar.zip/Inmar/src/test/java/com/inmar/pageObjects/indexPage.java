package com.inmar.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class indexPage {
	
	WebDriver ldriver;
	
	public indexPage(WebDriver rdriver)
	{
		ldriver  = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy(className="login")
	WebElement btnSignin;
	
	@FindBy(className="logout")
	WebElement btnSignout;
	
	

	public void clickSignin()
	{
		// TODO Auto-generated method stub
		btnSignin.click();
	}
	
	public void clickSignout()
	{
		// TODO Auto-generated method stub
		btnSignout.click();
	}

}
