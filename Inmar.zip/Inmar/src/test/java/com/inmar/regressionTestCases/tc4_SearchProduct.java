package com.inmar.regressionTestCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.inmar.pageObjects.indexPage;
import com.inmar.pageObjects.loginPage;
import com.inmar.pageObjects.myStorePage;
import com.inmar.pageObjects.paymentPage;

public class tc4_SearchProduct extends baseClass
{

	@Test
	public void tc1_HappyFlow() throws InterruptedException
	{
		indexPage ip = new indexPage(driver);
		loginPage lp = new loginPage(driver);
		myStorePage sp = new myStorePage(driver);
		paymentPage pp = new paymentPage(driver);
		
		driver.manage().window().maximize();
		
		Assert.assertEquals(driver.getTitle(), "My Store", "Home Page Title is not receiving as expected");
		
		ip.clickSignin();
		
		Assert.assertEquals(driver.getTitle(), "Login - My Store", "Login Page Title is not receiving as expected");
		
		lp.txtEmail(userName);
		lp.txtPassword(password);
		lp.btnSubmitLogin();
		
		Thread.sleep(5000);
		
		Assert.assertEquals(driver.getTitle(), "My account - My Store", "Not able to login to My Store");
		Thread.sleep(5000);
		
		sp.txtSearchQuery("Printed Summer Dress");
		sp.btnSearch();
		Assert.assertEquals(driver.getTitle(), "Search - My Store", "Search Product is not available");
		
	}
	
	
}
