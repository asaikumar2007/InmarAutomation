package com.inmar.regressionTestCases;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.inmar.pageObjects.indexPage;
import com.inmar.pageObjects.loginPage;
import com.inmar.pageObjects.myStorePage;
import com.inmar.pageObjects.paymentPage;

public class tc2_ProductPurchaseThroughPayByCheck extends baseClass 
{
	
	@Test
	public void tc2_HappyFlow() throws InterruptedException
	{
	indexPage ip = new indexPage(driver);
	loginPage lp = new loginPage(driver);
	myStorePage sp = new myStorePage(driver);
	paymentPage pp = new paymentPage(driver);
	
	driver.manage().window().maximize();
	
	Assert.assertEquals(driver.getTitle(), "My Store", "Home Page Title is not receiving as expected");
	
	ip.clickSignin();
	
	Assert.assertEquals(driver.getTitle(), "Login - My Store", "Login Page Title is not receiving as expected");
	
	lp.txtEmail(userName);
	lp.txtPassword(password);
	lp.btnSubmitLogin();
	
	Thread.sleep(5000);
	
	Assert.assertEquals(driver.getTitle(), "My account - My Store", "Not able to login to My Store");
	Thread.sleep(5000);
	sp.clickOnWomenStore();
	Assert.assertEquals(driver.getTitle(), "Women - My Store", "Not able to navigate to Women Store");
	
	Thread.sleep(5000);
	JavascriptExecutor js = (JavascriptExecutor) driver; 
	js.executeScript("window.scrollBy(0,1000)");
	
	Thread.sleep(5000);
	
	sp.moveToProdcut();
	Thread.sleep(5000);
	sp.clickOnAddToCart();
	Thread.sleep(5000);
		
	Assert.assertEquals(sp.addToCartMsg().trim(), "Product successfully added to your shopping cart");
	sp.clickOnProceedToCheckOutButton();
		
	Thread.sleep(5000);
	Assert.assertEquals(driver.getTitle(), "Order - My Store");
	sp.orderPageBtnProceedToCheckOut();
		
	Assert.assertTrue(sp.verifyBillingAddressCheckBox());
	sp.clickOnProcessAddessCheckOut();
	sp.clickOnShippingCheckBox();
		
	sp.clickOnProcessCarrierCheckOut();
		
	Thread.sleep(5000);
	pp.clickOnPaymentModeCheque();
	pp.clickOnBtnConfirmMyOrder();
		
	Thread.sleep(5000);
	Assert.assertEquals(driver.getTitle(), "Order confirmation - My Store", "Order is not placed properlly");
	Assert.assertEquals(pp.chequeOrderStatusMsg(), "Your order on My Store is complete.");
	}

}
