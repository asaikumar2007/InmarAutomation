package com.inmar.regressionTestCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import com.inmar.pageObjects.indexPage;
import com.inmar.utilities.readConfig;

public class baseClass 
{
	readConfig rc = new readConfig();
	public String baseURL = rc.getApplicationURL();
	public String userName = rc.getUserName();
	public String password = rc.getPassword();
	public static WebDriver driver;
	
	
	@Parameters("browser")
	@BeforeClass
	public void setup(String br)
	{
		if(br.equals("chrome"))
		{
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"//Drivers//chromedriver.exe");
		driver = new ChromeDriver();
		}
		else if(br.equals("ie"))
		{
			System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+"//Drivers//IEDriverServer.exe");
			driver = new InternetExplorerDriver();  
		}
		
		driver.get(baseURL);
	}
	
	
	@AfterClass
	public void tearDown()
	{
	//	indexPage ip = new indexPage(driver);
	//	ip.clickSignout();
		driver.quit();
	}
	
}
