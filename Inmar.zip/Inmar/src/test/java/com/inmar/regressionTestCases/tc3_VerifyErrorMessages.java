package com.inmar.regressionTestCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.inmar.pageObjects.indexPage;
import com.inmar.pageObjects.loginPage;
import com.inmar.pageObjects.myStorePage;
import com.inmar.pageObjects.paymentPage;

public class tc3_VerifyErrorMessages extends baseClass
{

	@Test
	public void tc3_VerifyErrorMessages() throws InterruptedException
	{
	indexPage ip = new indexPage(driver);
	loginPage lp = new loginPage(driver);
	myStorePage sp = new myStorePage(driver);
	paymentPage pp = new paymentPage(driver);
	
	driver.manage().window().maximize();
	
	Assert.assertEquals(driver.getTitle(), "My Store", "Home Page Title is not receiving as expected");
	
	ip.clickSignin();
	
	Assert.assertEquals(driver.getTitle(), "Login - My Store", "Login Page Title is not receiving as expected");
	
	lp.btnSubmitLogin();
	
	Assert.assertEquals(lp.getEmailErrorMsg(), "An email address required.", "email address is a required field");
	
	lp.txtEmail(userName);
	lp.btnSubmitLogin();
	Assert.assertEquals(lp.getEmailErrorMsg(), "Password is required.", "password is a required field");
	
	}
	

}
